export const WHATSAPP_NUMBER = "237672203290";
export const INSTAGRAM = "https://www.instagram.com/ws_fragrances";
export const TIKTOK = "https://www.tiktok.com/@ws_frangrances?_r=1&_t=ZG-96xKox84ruy";

export const NOTES = ["Oud", "Rose", "Musk", "Amber", "Vanilla", "Sandalwood", "Bergamot", "Jasmine", "Citrus", "Tobacco", "Patchouli", "Lavender"];

export const CATEGORIES_EN = [
  { id: "all", label: "All" },
  { id: "men", label: "For Him" },
  { id: "women", label: "For Her" },
  { id: "unisex", label: "Unisex" },
  { id: "oud", label: "Oud" },
  { id: "fresh", label: "Fresh" },
  { id: "oriental", label: "Oriental" },
];
export const CATEGORIES_FR = [
  { id: "all", label: "Tous" },
  { id: "men", label: "Pour Lui" },
  { id: "women", label: "Pour Elle" },
  { id: "unisex", label: "Unisexe" },
  { id: "oud", label: "Oud" },
  { id: "fresh", label: "Frais" },
  { id: "oriental", label: "Oriental" },
];

export const BRANDS = ["All", "Lattafa", "Afnan", "French Avenue", "Alhambra", "Paris Corner", "Armaf", "Maison Alhambra"];
export const BRANDS_FR = ["Tous", "Lattafa", "Afnan", "French Avenue", "Alhambra", "Paris Corner", "Armaf", "Maison Alhambra"];

// Color palettes per perfume — no emojis, rich gradients
export const PERFUMES = [
  {
    id: 1, name: "Oud For Glory", brand: "Lattafa", category: "unisex",
    price: 18500, originalPrice: 22000,
    notes: ["Oud", "Rose", "Musk", "Amber"],
    descEn: "A majestic oud fragrance blending rich agarwood with velvety rose and a warm amber base. Deeply luxurious, long-lasting.",
    descFr: "Une majestueuse fragrance oud mêlant un bois d'agar riche avec une rose veloutée et une base d'ambre chaude. Profondément luxueux.",
    size: "100ml EDP", rating: 4.9, reviews: 47, badge: "Best Seller",
    hue: "#8B4513", accent: "#C9A84C",
  },
  {
    id: 2, name: "Asad", brand: "Lattafa", category: "men",
    price: 16500, originalPrice: null,
    notes: ["Amber", "Tobacco", "Musk", "Vanilla"],
    descEn: "Bold and commanding. Asad opens with smoky tobacco layered over warm amber and rich musk. A true statement scent for men.",
    descFr: "Audacieux et dominant. Asad s'ouvre sur un tabac fumé sur fond d'ambre chaud et de musc riche. Une fragrance masculine affirmée.",
    size: "100ml EDP", rating: 4.8, reviews: 63, badge: "New",
    hue: "#3D1C00", accent: "#A0522D",
  },
  {
    id: 3, name: "Yara", brand: "Lattafa", category: "women",
    price: 14500, originalPrice: 17000,
    notes: ["Jasmine", "Rose", "Vanilla", "Musk"],
    descEn: "Yara is a delicate floral bouquet with a warm vanilla heart. Feminine, soft and irresistibly elegant.",
    descFr: "Yara est un délicat bouquet floral avec un cœur de vanille chaude. Féminin, doux et irrésistiblement élégant.",
    size: "100ml EDP", rating: 4.7, reviews: 38, badge: "Best Seller",
    hue: "#6B0040", accent: "#D4578C",
  },
  {
    id: 4, name: "Black Afgano", brand: "Afnan", category: "unisex",
    price: 21000, originalPrice: 25000,
    notes: ["Oud", "Patchouli", "Tobacco", "Musk"],
    descEn: "Dark, mysterious, and unforgettable. A smoky, resinous oud masterpiece with deep patchouli and tobacco.",
    descFr: "Sombre, mystérieux et inoubliable. Un chef-d'œuvre d'oud résineux et fumé avec un patchouli profond et du tabac.",
    size: "100ml EDP", rating: 5.0, reviews: 29, badge: "Premium",
    hue: "#1A0A2E", accent: "#7B5EA7",
  },
  {
    id: 5, name: "9PM", brand: "Afnan", category: "men",
    price: 19500, originalPrice: null,
    notes: ["Bergamot", "Amber", "Vanilla", "Musk"],
    descEn: "Fresh citrus opening descending into a warm, sensual amber and vanilla drydown. Perfect for evenings.",
    descFr: "Une ouverture d'agrumes frais descendant vers un fond d'ambre chaud et de vanille. Parfait pour les soirées.",
    size: "100ml EDP", rating: 4.9, reviews: 82, badge: "Top Pick",
    hue: "#0A0A2E", accent: "#4444CC",
  },
  {
    id: 6, name: "Supremacy Silver", brand: "Afnan", category: "men",
    price: 15000, originalPrice: 18000,
    notes: ["Bergamot", "Lavender", "Sandalwood", "Musk"],
    descEn: "A crisp, sophisticated fresh scent. Silver accords with lavender and sandalwood for the modern gentleman.",
    descFr: "Un parfum frais et sophistiqué. Des accords argentés avec lavande et santal pour le gentleman moderne.",
    size: "100ml EDP", rating: 4.6, reviews: 55, badge: null,
    hue: "#2A2A2A", accent: "#A0A0A0",
  },
  {
    id: 7, name: "Avenue Des Fleurs", brand: "French Avenue", category: "women",
    price: 13500, originalPrice: null,
    notes: ["Rose", "Jasmine", "Bergamot", "Sandalwood"],
    descEn: "A Parisian floral stroll. Crisp bergamot onto a lush rose and jasmine heart, softly wrapped in sandalwood.",
    descFr: "Une promenade florale parisienne. Bergamote croquante sur un cœur de rose et jasmin enveloppé de santal.",
    size: "100ml EDP", rating: 4.5, reviews: 24, badge: null,
    hue: "#5C0030", accent: "#E87AAB",
  },
  {
    id: 8, name: "Signature Gold", brand: "French Avenue", category: "unisex",
    price: 17500, originalPrice: 21000,
    notes: ["Amber", "Rose", "Oud", "Musk"],
    descEn: "An opulent signature blending golden amber with rich oud and soft rose. Wear it as your personal seal of luxury.",
    descFr: "Une signature opulente mêlant ambre doré, oud riche et rose douce. Portez-le comme votre sceau personnel de luxe.",
    size: "100ml EDP", rating: 4.7, reviews: 31, badge: "Sale",
    hue: "#4A3200", accent: "#C9A84C",
  },
  {
    id: 9, name: "Andalucia", brand: "Alhambra", category: "women",
    price: 12500, originalPrice: null,
    notes: ["Jasmine", "Citrus", "Vanilla", "Musk"],
    descEn: "Sun-drenched and joyful. Andalucia evokes southern warmth with radiant jasmine and fresh citrus.",
    descFr: "Ensoleillée et joyeuse. Andalucia évoque la chaleur du sud avec un jasmin rayonnant et des agrumes frais.",
    size: "100ml EDP", rating: 4.4, reviews: 19, badge: null,
    hue: "#5C3A00", accent: "#E8A020",
  },
  {
    id: 10, name: "Steadfast", brand: "Paris Corner", category: "men",
    price: 15500, originalPrice: 18500,
    notes: ["Tobacco", "Oud", "Amber", "Sandalwood"],
    descEn: "Bold and unwavering — a powerful blend of tobacco leaf, oud resin and warm sandalwood. Commanding presence.",
    descFr: "Audacieux et déterminé — un puissant mélange de feuille de tabac, résine d'oud et santal chaud.",
    size: "100ml EDP", rating: 4.8, reviews: 41, badge: "Best Seller",
    hue: "#1E0A00", accent: "#7B3A00",
  },
  {
    id: 11, name: "Millionaire", brand: "Paris Corner", category: "men",
    price: 20000, originalPrice: 24000,
    notes: ["Bergamot", "Jasmine", "Amber", "Vanilla"],
    descEn: "Opens bright with bergamot, reveals a floral jasmine heart, and settles into pure luxury.",
    descFr: "S'ouvre brillamment sur la bergamote, révèle un cœur floral de jasmin et se fixe dans le luxe pur.",
    size: "100ml EDP", rating: 4.9, reviews: 58, badge: "Premium",
    hue: "#2A2A00", accent: "#C8A800",
  },
  {
    id: 12, name: "Club De Nuit", brand: "Armaf", category: "men",
    price: 16000, originalPrice: null,
    notes: ["Bergamot", "Patchouli", "Amber", "Musk"],
    descEn: "The iconic Creed Aventus-inspired fragrance. Fresh, smoky, timeless. A must-have for every collection.",
    descFr: "L'iconique fragrance inspirée de Creed Aventus. Fraîche, fumée, intemporelle. Un incontournable.",
    size: "105ml EDP", rating: 5.0, reviews: 96, badge: "Iconic",
    hue: "#00001A", accent: "#3366CC",
  },
  {
    id: 13, name: "Tres Nuit", brand: "Armaf", category: "men",
    price: 14000, originalPrice: 16500,
    notes: ["Lavender", "Bergamot", "Sandalwood", "Vanilla"],
    descEn: "A refined, versatile gentleman's fragrance. Lavender and bergamot into warm sandalwood and vanilla.",
    descFr: "Une fragrance masculine raffinée et polyvalente. Lavande et bergamote vers santal chaud et vanille.",
    size: "100ml EDP", rating: 4.7, reviews: 44, badge: "Sale",
    hue: "#0A001A", accent: "#6600CC",
  },
  {
    id: 14, name: "Hayati", brand: "Maison Alhambra", category: "unisex",
    price: 13000, originalPrice: null,
    notes: ["Rose", "Oud", "Musk", "Amber"],
    descEn: "Hayati means 'my life' in Arabic — rose and oud intertwined with musky warmth.",
    descFr: "Hayati signifie 'ma vie' en arabe — rose et oud entrelacés avec une chaleur musquée.",
    size: "100ml EDP", rating: 4.6, reviews: 27, badge: null,
    hue: "#3D0020", accent: "#CC006B",
  },
  {
    id: 15, name: "Ameer Al Oud", brand: "Afnan", category: "unisex",
    price: 23000, originalPrice: 28000,
    notes: ["Oud", "Rose", "Sandalwood", "Amber"],
    descEn: "Prince of Oud — a royal composition of aged agarwood, Taif rose, and creamy sandalwood.",
    descFr: "Prince de l'Oud — une composition royale de bois d'agar vieilli, de rose de Taïf et de santal crémeux.",
    size: "100ml EDP", rating: 5.0, reviews: 35, badge: "Luxury",
    hue: "#2A1000", accent: "#9B6910",
  },
  {
    id: 16, name: "Lady Millions", brand: "French Avenue", category: "women",
    price: 15000, originalPrice: null,
    notes: ["Rose", "Jasmine", "Vanilla", "Musk"],
    descEn: "Glamorous and confident. Rose and jasmine fizz at the top while jasmine-vanilla leaves a trail of femininity.",
    descFr: "Glamour et confiance. Rose et jasmin pétillent en tête tandis que la base jasmin-vanille laisse un sillage de féminité.",
    size: "100ml EDP", rating: 4.8, reviews: 52, badge: "New",
    hue: "#3D0028", accent: "#E880CC",
  },
];

export function getWhatsAppLink(perfumeName, size) {
  const msg = encodeURIComponent(`Hello W&S Fragrances! 👋\n\nI'd like to order:\n*${perfumeName}* (${size})\n\nPlease confirm availability and delivery. Thank you!`);
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`;
}
