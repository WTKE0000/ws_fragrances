const brands = [
  { name: 'Lattafa', origin: 'UAE', specialty: 'Oud & Oriental', emoji: '🇦🇪' },
  { name: 'Afnan', origin: 'UAE', specialty: 'Luxury Niche', emoji: '✨' },
  { name: 'French Avenue', origin: 'France', specialty: 'Floral & Fresh', emoji: '🇫🇷' },
  { name: 'Alhambra', origin: 'UAE', specialty: 'Oriental Blends', emoji: '🏰' },
  { name: 'Paris Corner', origin: 'UAE', specialty: 'Premium Woody', emoji: '🗼' },
  { name: 'Armaf', origin: 'UAE', specialty: 'Designer Dupes', emoji: '💎' },
  { name: 'Maison Alhambra', origin: 'UAE', specialty: 'Rose & Oud', emoji: '🌹' },
];

export default function Brands() {
  return (
    <section className="page-section" id="brands" style={{ background: 'var(--bg-dark)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <div className="section-subtitle">Our Partners</div>
          <h2 className="section-title">Premium <em>Brands</em></h2>
          <p style={{ color: 'var(--text-secondary)', marginTop: '0.75rem', maxWidth: '480px', margin: '0.75rem auto 0' }}>
            We carry only authentic products from the world's most prestigious fragrance houses
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1px', background: 'var(--border)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
          {brands.map(brand => (
            <div key={brand.name} style={{
              background: 'var(--bg-card)', padding: '2rem 1.5rem',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem',
              textAlign: 'center', transition: 'var(--transition)', cursor: 'default'
            }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-hover)'}
              onMouseLeave={e => e.currentTarget.style.background = 'var(--bg-card)'}
            >
              <div style={{ fontSize: '2rem' }}>{brand.emoji}</div>
              <div style={{ fontFamily: 'var(--font-serif)', fontSize: '1.2rem', color: 'var(--text-primary)' }}>{brand.name}</div>
              <div style={{ fontSize: '0.65rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--gold)' }}>{brand.origin}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{brand.specialty}</div>
            </div>
          ))}
        </div>

        {/* Trust badges */}
        <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: '2rem', marginTop: '3rem', paddingTop: '2rem', borderTop: '1px solid var(--border)' }}>
          {[
            { icon: '✅', label: '100% Authentic', desc: 'Direct from brand distributors' },
            { icon: '🚚', label: 'Cameroon Delivery', desc: 'Nationwide shipping available' },
            { icon: '💬', label: 'WhatsApp Orders', desc: 'Fast, easy, secure ordering' },
            { icon: '🔒', label: 'Trusted by 500+', desc: 'Happy customers across CMR' },
          ].map(b => (
            <div key={b.label} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flex: '0 0 auto' }}>
              <span style={{ fontSize: '1.5rem' }}>{b.icon}</span>
              <div>
                <div style={{ fontSize: '0.8rem', fontWeight: 500, color: 'var(--text-primary)' }}>{b.label}</div>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{b.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
