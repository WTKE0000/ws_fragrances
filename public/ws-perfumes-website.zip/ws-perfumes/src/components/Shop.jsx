import { useState, useMemo } from 'react';
import { PERFUMES, CATEGORIES, BRANDS, NOTES } from '../data.js';
import { PerfumeCard, PerfumeModal } from './PerfumeCard.jsx';

export default function Shop() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedBrand, setSelectedBrand] = useState('All Brands');
  const [selectedNotes, setSelectedNotes] = useState([]);
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('default');
  const [selectedPerfume, setSelectedPerfume] = useState(null);

  const toggleNote = (note) => {
    setSelectedNotes(prev =>
      prev.includes(note) ? prev.filter(n => n !== note) : [...prev, note]
    );
  };

  const filtered = useMemo(() => {
    let list = [...PERFUMES];
    if (selectedCategory !== 'all') {
      if (selectedCategory === 'oud') list = list.filter(p => p.notes.includes('Oud'));
      else if (selectedCategory === 'fresh') list = list.filter(p => p.notes.some(n => ['Bergamot', 'Citrus', 'Lavender'].includes(n)));
      else if (selectedCategory === 'oriental') list = list.filter(p => p.notes.some(n => ['Oud', 'Amber', 'Musk', 'Sandalwood'].includes(n)));
      else list = list.filter(p => p.category === selectedCategory);
    }
    if (selectedBrand !== 'All Brands') list = list.filter(p => p.brand === selectedBrand);
    if (selectedNotes.length > 0) list = list.filter(p => selectedNotes.every(n => p.notes.includes(n)));
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(p => p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q) || p.notes.some(n => n.toLowerCase().includes(q)));
    }
    if (sortBy === 'price-asc') list.sort((a, b) => a.price - b.price);
    else if (sortBy === 'price-desc') list.sort((a, b) => b.price - a.price);
    else if (sortBy === 'rating') list.sort((a, b) => b.rating - a.rating);
    else if (sortBy === 'popular') list.sort((a, b) => b.reviews - a.reviews);
    return list;
  }, [selectedCategory, selectedBrand, selectedNotes, search, sortBy]);

  return (
    <section className="page-section" id="shop">
      <div className="container">
        <div style={{ marginBottom: '3rem', textAlign: 'center' }}>
          <div className="section-subtitle">Our Collection</div>
          <h2 className="section-title">Discover Your <em>Signature</em></h2>
          <p style={{ color: 'var(--text-secondary)', marginTop: '0.75rem', maxWidth: '480px', margin: '0.75rem auto 0' }}>
            Browse our curated selection of authentic Middle Eastern and French fragrances
          </p>
        </div>

        {/* Search + Sort */}
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center', marginBottom: '1.5rem' }}>
          <div className="search-wrap" style={{ flex: '1', minWidth: '200px' }}>
            <svg className="search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
            <input
              type="text"
              placeholder="Search perfumes, brands, notes..."
              className="search-input"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value)}
            style={{
              padding: '0.75rem 1rem', background: 'var(--bg-card)',
              border: '1px solid var(--border)', color: 'var(--text-secondary)',
              fontFamily: 'var(--font-sans)', fontSize: '0.8rem', borderRadius: 'var(--radius)',
              outline: 'none', cursor: 'pointer'
            }}
          >
            <option value="default">Sort: Default</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
            <option value="popular">Most Popular</option>
          </select>
        </div>

        {/* Category filters */}
        <div className="filter-bar" style={{ marginBottom: '0.75rem' }}>
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              className={`filter-btn ${selectedCategory === cat.id ? 'active' : ''}`}
              onClick={() => setSelectedCategory(cat.id)}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Brand filters */}
        <div className="filter-bar" style={{ marginBottom: '0.75rem' }}>
          {BRANDS.map(brand => (
            <button
              key={brand}
              className={`filter-btn ${selectedBrand === brand ? 'active' : ''}`}
              onClick={() => setSelectedBrand(brand)}
              style={{ fontSize: '0.7rem' }}
            >
              {brand}
            </button>
          ))}
        </div>

        {/* Notes filter */}
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ fontSize: '0.65rem', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '0.6rem' }}>
            Filter by Notes:
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
            {NOTES.map(note => (
              <span
                key={note}
                className={`note-pill ${selectedNotes.includes(note) ? 'active' : ''}`}
                style={{ cursor: 'pointer' }}
                onClick={() => toggleNote(note)}
              >
                {note}
              </span>
            ))}
          </div>
        </div>

        {/* Results count */}
        <div style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            {filtered.length} {filtered.length === 1 ? 'perfume' : 'perfumes'} found
          </span>
          {(selectedNotes.length > 0 || selectedBrand !== 'All Brands' || search) && (
            <button
              onClick={() => { setSelectedNotes([]); setSelectedBrand('All Brands'); setSearch(''); setSelectedCategory('all'); }}
              style={{ fontSize: '0.75rem', color: 'var(--gold)', background: 'none', border: 'none', cursor: 'pointer', letterSpacing: '0.05em' }}
            >
              Clear filters ✕
            </button>
          )}
        </div>

        {/* Grid */}
        {filtered.length > 0 ? (
          <div className="perfume-grid">
            {filtered.map((p, i) => (
              <div key={p.id} style={{ animationDelay: `${i * 0.05}s` }}>
                <PerfumeCard perfume={p} onClick={setSelectedPerfume} />
              </div>
            ))}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '4rem 0', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🔍</div>
            <p>No perfumes found. Try adjusting your filters.</p>
          </div>
        )}
      </div>

      {selectedPerfume && (
        <PerfumeModal perfume={selectedPerfume} onClose={() => setSelectedPerfume(null)} />
      )}
    </section>
  );
}
