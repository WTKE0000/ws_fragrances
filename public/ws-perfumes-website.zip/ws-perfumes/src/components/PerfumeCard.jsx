import { useState } from 'react';
import { getWhatsAppLink } from '../data.js';

function Stars({ rating }) {
  return (
    <span className="stars">
      {'★'.repeat(Math.floor(rating))}{'☆'.repeat(5 - Math.floor(rating))}
    </span>
  );
}

export function PerfumeModal({ perfume, onClose }) {
  if (!perfume) return null;
  const waLink = getWhatsAppLink(perfume.name, perfume.size);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-visual" style={{ background: perfume.gradient }}>
          <div className="modal-visual-emoji">{perfume.emoji}</div>
          <button onClick={onClose} style={{
            position: 'absolute', top: '1rem', right: '1rem',
            background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.2)',
            color: '#fff', width: '36px', height: '36px', borderRadius: '50%',
            cursor: 'pointer', fontSize: '1.1rem', display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}>✕</button>
          {perfume.badge && <span className="badge badge-gold" style={{ position: 'absolute', top: '1rem', left: '1rem' }}>{perfume.badge}</span>}
        </div>

        <div className="modal-body">
          <div style={{ marginBottom: '0.25rem', fontSize: '0.65rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--gold)' }}>
            {perfume.brand}
          </div>
          <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: '2rem', fontWeight: 300, marginBottom: '0.5rem' }}>
            {perfume.name}
          </h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.25rem' }}>
            <Stars rating={perfume.rating} />
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{perfume.rating} ({perfume.reviews} reviews)</span>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{perfume.size}</span>
          </div>

          <p style={{ color: 'var(--text-secondary)', lineHeight: 1.8, marginBottom: '1.5rem' }}>{perfume.description}</p>

          <div style={{ marginBottom: '1.5rem' }}>
            <div style={{ fontSize: '0.65rem', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '0.6rem' }}>
              Fragrance Notes
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
              {perfume.notes.map(n => <span key={n} className="note-pill active">{n}</span>)}
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
            <div>
              <span style={{ fontFamily: 'var(--font-serif)', fontSize: '2rem', color: 'var(--gold)', fontWeight: 300 }}>
                {perfume.price.toLocaleString()} FCFA
              </span>
              {perfume.originalPrice && (
                <span style={{ fontSize: '1rem', color: 'var(--text-muted)', textDecoration: 'line-through', marginLeft: '0.5rem' }}>
                  {perfume.originalPrice.toLocaleString()}
                </span>
              )}
            </div>
            <span className="badge badge-green">In Stock</span>
          </div>

          <a href={waLink} target="_blank" rel="noopener noreferrer" className="btn btn-whatsapp" style={{ width: '100%', justifyContent: 'center', padding: '0.875rem' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            Order via WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
}

export function PerfumeCard({ perfume, onClick }) {
  return (
    <div className="perfume-card animate-fade-in" onClick={() => onClick(perfume)}>
      {perfume.badge && (
        <div className="perfume-card-badge">
          <span className="badge badge-gold">{perfume.badge}</span>
        </div>
      )}
      <div className="perfume-card-visual" style={{ background: perfume.gradient }}>
        <div className="perfume-card-glow" style={{ background: perfume.gradient }} />
        <div className="perfume-card-emoji">{perfume.emoji}</div>
      </div>
      <div className="perfume-card-body">
        <div className="perfume-card-brand">{perfume.brand}</div>
        <div className="perfume-card-name">{perfume.name}</div>
        <div className="perfume-card-notes">
          {perfume.notes.slice(0, 3).map(n => (
            <span key={n} className="note-pill">{n}</span>
          ))}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Stars rating={perfume.rating} />
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>({perfume.reviews})</span>
        </div>
        <div className="perfume-card-footer">
          <div>
            <span className="perfume-card-price">{perfume.price.toLocaleString()}</span>
            <span style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', marginLeft: '0.25rem' }}>FCFA</span>
            {perfume.originalPrice && (
              <span className="perfume-card-price-orig">{perfume.originalPrice.toLocaleString()}</span>
            )}
          </div>
          <span style={{ fontSize: '0.7rem', color: 'var(--gold)', letterSpacing: '0.05em' }}>View →</span>
        </div>
      </div>
    </div>
  );
}
