export default function About() {
  return (
    <section className="page-section about-section" id="about" style={{ background: 'var(--bg-dark)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
      <div className="container">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '5rem', alignItems: 'center' }}>
          <div>
            <div className="section-subtitle">Our Story</div>
            <h2 className="section-title" style={{ marginBottom: '1.5rem' }}>
              Bringing the <em>World's Finest</em> Scents to Cameroon
            </h2>
            <p style={{ color: 'var(--text-secondary)', lineHeight: 1.9, marginBottom: '1.25rem' }}>
              W&S Fragrances was born from a passion for authentic, luxury perfumery. We believe everyone in Cameroon deserves access to the world's finest Middle Eastern and French fragrances — at fair, honest prices.
            </p>
            <p style={{ color: 'var(--text-secondary)', lineHeight: 1.9, marginBottom: '2rem' }}>
              We source directly from trusted distributors of brands like Lattafa, Afnan, Armaf and more — guaranteeing 100% authenticity on every bottle we sell. Our WhatsApp-based ordering makes it fast, personal, and easy to get your favorite scent.
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '2rem' }}>
              {[
                { num: '500+', label: 'Happy Customers' },
                { num: '7+', label: 'Premium Brands' },
                { num: '100%', label: 'Authentic Products' },
                { num: '2yr+', label: 'In Business' },
              ].map(s => (
                <div key={s.label} style={{ padding: '1.25rem', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius)' }}>
                  <div style={{ fontFamily: 'var(--font-serif)', fontSize: '2rem', color: 'var(--gold)', fontWeight: 300, lineHeight: 1 }}>{s.num}</div>
                  <div style={{ fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--text-muted)', marginTop: '0.25rem' }}>{s.label}</div>
                </div>
              ))}
            </div>

            <a href="#contact" className="btn btn-gold">Get in Touch</a>
          </div>

          {/* Visual side */}
          <div style={{ position: 'relative' }}>
            <div style={{
              background: 'linear-gradient(135deg, rgba(201,168,76,0.08) 0%, rgba(139,69,19,0.12) 100%)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-lg)',
              padding: '3rem',
              textAlign: 'center',
              position: 'relative',
              overflow: 'hidden'
            }}>
              <div style={{ fontSize: '8rem', marginBottom: '1.5rem', display: 'block', filter: 'drop-shadow(0 0 30px rgba(201,168,76,0.3))' }}>🪔</div>
              <div style={{ fontFamily: 'var(--font-serif)', fontSize: '1.5rem', fontWeight: 300, marginBottom: '0.5rem', color: 'var(--text-primary)' }}>
                "A great scent tells your story<br />before you speak"
              </div>
              <div style={{ fontSize: '0.7rem', letterSpacing: '0.15em', color: 'var(--gold)', textTransform: 'uppercase' }}>
                — W&S Fragrances
              </div>
            </div>

            {/* Values list */}
            <div style={{ marginTop: '1.5rem', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {[
                { icon: '🌿', title: 'Authenticity First', desc: 'Every bottle guaranteed genuine' },
                { icon: '📦', title: 'Fast Delivery', desc: 'Shipped across Cameroon' },
                { icon: '💬', title: 'Personal Service', desc: 'Direct WhatsApp support' },
              ].map(v => (
                <div key={v.title} style={{
                  display: 'flex', alignItems: 'center', gap: '1rem',
                  padding: '0.875rem 1rem',
                  background: 'var(--bg-card)', border: '1px solid var(--border)',
                  borderRadius: 'var(--radius)',
                  transition: 'var(--transition)'
                }}>
                  <span style={{ fontSize: '1.25rem' }}>{v.icon}</span>
                  <div>
                    <div style={{ fontSize: '0.875rem', fontWeight: 500 }}>{v.title}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{v.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          #about .container > div { grid-template-columns: 1fr !important; gap: 2.5rem !important; }
        }
      `}</style>
    </section>
  );
}
