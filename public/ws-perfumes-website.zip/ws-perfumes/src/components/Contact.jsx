import { useState } from 'react';
import { WHATSAPP_NUMBER, INSTAGRAM, TIKTOK } from '../data.js';

export default function Contact() {
  const [form, setForm] = useState({ name: '', phone: '', perfume: '', message: '' });
  const [sent, setSent] = useState(false);

  const buildWhatsAppMessage = () => {
    const lines = [
      `Hello W&S Fragrances! 👋`,
      ``,
      `Name: ${form.name}`,
      form.phone ? `Phone: ${form.phone}` : '',
      form.perfume ? `Interested in: ${form.perfume}` : '',
      ``,
      form.message || 'I would like to know more about your collection.',
    ].filter(l => l !== undefined);
    return encodeURIComponent(lines.join('\n'));
  };

  const handleSend = () => {
    if (!form.name) return;
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${buildWhatsAppMessage()}`, '_blank');
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <section className="page-section" id="contact">
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <div className="section-subtitle">Get in Touch</div>
          <h2 className="section-title">Ready to Order? <em>Let's Talk</em></h2>
          <p style={{ color: 'var(--text-secondary)', marginTop: '0.75rem', maxWidth: '460px', margin: '0.75rem auto 0' }}>
            Reach out via WhatsApp for orders, enquiries, or custom requests. We typically respond within minutes.
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: '3rem', alignItems: 'start' }}>
          {/* Info side */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {/* Direct WhatsApp */}
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: 'flex', alignItems: 'center', gap: '1rem',
                padding: '1.5rem',
                background: 'rgba(37,211,102,0.06)',
                border: '1px solid rgba(37,211,102,0.2)',
                borderRadius: 'var(--radius-lg)',
                transition: 'var(--transition)', textDecoration: 'none'
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'rgba(37,211,102,0.12)'}
              onMouseLeave={e => e.currentTarget.style.background = 'rgba(37,211,102,0.06)'}
            >
              <div style={{
                width: '50px', height: '50px', background: '#25d366', borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
              }}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              </div>
              <div>
                <div style={{ fontWeight: 500, color: '#25d366' }}>WhatsApp Direct</div>
                <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>+237 672 203 290</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Tap to chat instantly</div>
              </div>
            </a>

            {/* Social links */}
            <div style={{ padding: '1.5rem', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)' }}>
              <div style={{ fontSize: '0.65rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1.25rem' }}>Follow Us</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
                <a href={INSTAGRAM} target="_blank" rel="noopener noreferrer" style={{ display: 'flex', alignItems: 'center', gap: '0.875rem', color: 'var(--text-secondary)', transition: 'var(--transition)', textDecoration: 'none' }}
                  onMouseEnter={e => e.currentTarget.style.color = '#e1306c'}
                  onMouseLeave={e => e.currentTarget.style.color = 'var(--text-secondary)'}
                >
                  <span style={{ fontSize: '1.25rem' }}>📸</span>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: 'inherit' }}>Instagram</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>@ws_fragrances</div>
                  </div>
                </a>
                <a href={TIKTOK} target="_blank" rel="noopener noreferrer" style={{ display: 'flex', alignItems: 'center', gap: '0.875rem', color: 'var(--text-secondary)', transition: 'var(--transition)', textDecoration: 'none' }}
                  onMouseEnter={e => e.currentTarget.style.color = '#fff'}
                  onMouseLeave={e => e.currentTarget.style.color = 'var(--text-secondary)'}
                >
                  <span style={{ fontSize: '1.25rem' }}>🎵</span>
                  <div>
                    <div style={{ fontSize: '0.875rem', color: 'inherit' }}>TikTok</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>@ws_frangrances</div>
                  </div>
                </a>
              </div>
            </div>

            {/* Hours */}
            <div style={{ padding: '1.5rem', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)' }}>
              <div style={{ fontSize: '0.65rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '1rem' }}>Response Hours</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {[
                  { day: 'Mon – Fri', hours: '8:00 AM – 9:00 PM' },
                  { day: 'Saturday', hours: '9:00 AM – 8:00 PM' },
                  { day: 'Sunday', hours: '10:00 AM – 6:00 PM' },
                ].map(h => (
                  <div key={h.day} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem' }}>
                    <span style={{ color: 'var(--text-muted)' }}>{h.day}</span>
                    <span style={{ color: 'var(--text-secondary)' }}>{h.hours}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Form side */}
          <div className="contact-card">
            <h3 style={{ fontFamily: 'var(--font-serif)', fontSize: '1.5rem', fontWeight: 300, marginBottom: '1.5rem' }}>
              Send us a <span style={{ color: 'var(--gold)', fontStyle: 'italic' }}>message</span>
            </h3>
            <div className="contact-form">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <input placeholder="Your name *" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} style={{ marginBottom: 0 }} />
                <input placeholder="Phone / WhatsApp" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} style={{ marginBottom: 0 }} />
              </div>
              <div style={{ height: '1rem' }} />
              <input placeholder="Perfume you're interested in (optional)" value={form.perfume} onChange={e => setForm(f => ({ ...f, perfume: e.target.value }))} />
              <textarea placeholder="Your message or order details..." value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))} />

              <button className="btn btn-whatsapp" onClick={handleSend} style={{ width: '100%', justifyContent: 'center', padding: '0.875rem', fontSize: '0.8rem' }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                {sent ? '✓ Opening WhatsApp...' : 'Send via WhatsApp'}
              </button>
              <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textAlign: 'center', marginTop: '0.75rem', lineHeight: 1.6 }}>
                This will open WhatsApp with your message pre-filled.
              </p>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          #contact .container > div { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </section>
  );
}
