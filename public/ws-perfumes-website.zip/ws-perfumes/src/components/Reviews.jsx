import { useState } from 'react';
import { PERFUMES } from '../data.js';

const INITIAL_REVIEWS = [
  { id: 1, name: 'Amara K.', perfume: 'Club De Nuit', rating: 5, text: 'Absolutely incredible! This is better than the original Creed Aventus. I wear it every day to the office and receive so many compliments. Will definitely reorder.', date: 'May 2025', city: 'Yaoundé' },
  { id: 2, name: 'Didier N.', perfume: 'Asad', rating: 5, text: 'Puissant et élégant. Une fragrance qui dure toute la journée. Je l\'ai commandé via WhatsApp et la livraison était rapide. Très satisfait!', date: 'Apr 2025', city: 'Douala' },
  { id: 3, name: 'Chioma E.', perfume: 'Yara', rating: 5, text: 'Such a beautiful feminine scent! Sweet but not overpowering. My husband loves it on me. The WhatsApp ordering was seamless. 10/10!', date: 'Mar 2025', city: 'Bafoussam' },
  { id: 4, name: 'Ibrahim S.', perfume: 'Oud For Glory', rating: 5, text: 'Royal scent. True oud that lasts all day and into the night. W&S is the real deal — authentic products and great customer service.', date: 'Feb 2025', city: 'Garoua' },
  { id: 5, name: 'Pascale M.', perfume: '9PM', rating: 5, text: 'The 9PM is divine! So sexy and modern. Perfect for evenings out. The price is very fair for what you get. Already recommended to 5 friends!', date: 'Jan 2025', city: 'Yaoundé' },
  { id: 6, name: 'Serge T.', perfume: 'Millionaire', rating: 4, text: 'Great fragrance, great quality. Smells like a true luxury perfume. Delivery was fast and packaging was neat. One star off only because it sold out quickly!', date: 'Dec 2024', city: 'Douala' },
];

function Stars({ rating, size = '0.9rem', interactive = false, onSelect }) {
  return (
    <span style={{ color: 'var(--gold)', fontSize: size, letterSpacing: '0.1em', cursor: interactive ? 'pointer' : 'default' }}>
      {[1,2,3,4,5].map(i => (
        <span key={i} onClick={() => interactive && onSelect && onSelect(i)} style={{ cursor: interactive ? 'pointer' : 'default' }}>
          {i <= rating ? '★' : '☆'}
        </span>
      ))}
    </span>
  );
}

export default function Reviews() {
  const [reviews, setReviews] = useState(INITIAL_REVIEWS);
  const [form, setForm] = useState({ name: '', perfume: '', rating: 5, text: '', city: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.text || !form.perfume) return;
    setReviews(prev => [{
      id: Date.now(),
      ...form,
      date: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
    }, ...prev]);
    setForm({ name: '', perfume: '', rating: 5, text: '', city: '' });
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const avg = (reviews.reduce((a, r) => a + r.rating, 0) / reviews.length).toFixed(1);

  return (
    <section className="page-section" id="reviews">
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <div className="section-subtitle">Customer Voices</div>
          <h2 className="section-title">What Our <em>Clients</em> Say</h2>
          <div style={{ marginTop: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem' }}>
            <Stars rating={5} size="1.2rem" />
            <span style={{ fontFamily: 'var(--font-serif)', fontSize: '2rem', color: 'var(--gold)' }}>{avg}</span>
            <span style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>from {reviews.length} reviews</span>
          </div>
        </div>

        {/* Reviews grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.25rem', marginBottom: '4rem' }}>
          {reviews.map(r => (
            <div key={r.id} className="review-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <div style={{
                    width: '40px', height: '40px', borderRadius: '50%',
                    background: 'var(--bg-card2)', border: '1px solid var(--border)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontFamily: 'var(--font-serif)', color: 'var(--gold)', fontWeight: 300
                  }}>
                    {r.name[0]}
                  </div>
                  <div>
                    <div style={{ fontWeight: 500, fontSize: '0.875rem' }}>{r.name}</div>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{r.city} · {r.date}</div>
                  </div>
                </div>
                <Stars rating={r.rating} />
              </div>
              <div style={{ fontSize: '0.65rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: '0.5rem' }}>
                {r.perfume}
              </div>
              <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.7, fontStyle: 'italic' }}>
                "{r.text}"
              </p>
            </div>
          ))}
        </div>

        {/* Submit review form */}
        <div style={{ maxWidth: '600px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
            <div className="section-subtitle">Share Your Experience</div>
            <h3 style={{ fontFamily: 'var(--font-serif)', fontSize: '1.8rem', fontWeight: 300 }}>
              Leave a <em style={{ color: 'var(--gold)', fontStyle: 'italic' }}>Review</em>
            </h3>
          </div>

          {submitted ? (
            <div style={{ textAlign: 'center', padding: '2rem', background: 'var(--bg-card)', border: '1px solid var(--gold)', borderRadius: 'var(--radius-lg)' }}>
              <div style={{ fontSize: '2rem', marginBottom: '0.75rem' }}>✨</div>
              <p style={{ color: 'var(--gold)', fontFamily: 'var(--font-serif)', fontSize: '1.2rem' }}>Thank you for your review!</p>
            </div>
          ) : (
            <div className="contact-card">
              <div className="contact-form">
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <input placeholder="Your name *" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} style={{ marginBottom: 0 }} />
                  <input placeholder="City" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} style={{ marginBottom: 0 }} />
                </div>
                <div style={{ height: '1rem' }} />
                <select value={form.perfume} onChange={e => setForm(f => ({ ...f, perfume: e.target.value }))}>
                  <option value="">Select a perfume *</option>
                  {PERFUMES.map(p => <option key={p.id} value={p.name}>{p.name} — {p.brand}</option>)}
                </select>
                <div style={{ marginBottom: '1rem' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.5rem' }}>Your rating:</div>
                  <Stars rating={form.rating} size="1.5rem" interactive onSelect={r => setForm(f => ({ ...f, rating: r }))} />
                </div>
                <textarea placeholder="Share your experience with this perfume... *" value={form.text} onChange={e => setForm(f => ({ ...f, text: e.target.value }))} />
                <button className="btn btn-gold" onClick={handleSubmit} style={{ width: '100%', justifyContent: 'center', padding: '0.875rem' }}>
                  Submit Review
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
