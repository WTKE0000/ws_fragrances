export const WHATSAPP_NUMBER = "237672203290";
export const INSTAGRAM = "https://www.instagram.com/ws_fragrances";
export const TIKTOK = "https://www.tiktok.com/@ws_frangrances?_r=1&_t=ZG-96xKox84ruy";

export const NOTES = ["Oud", "Rose", "Musk", "Amber", "Vanilla", "Sandalwood", "Bergamot", "Jasmine", "Citrus", "Tobacco", "Patchouli", "Lavender"];

export const CATEGORIES = [
  { id: "all", label: "All Perfumes" },
  { id: "men", label: "For Him" },
  { id: "women", label: "For Her" },
  { id: "unisex", label: "Unisex" },
  { id: "oud", label: "Oud Collection" },
  { id: "fresh", label: "Fresh & Citrus" },
  { id: "oriental", label: "Oriental" },
];

export const BRANDS = ["All Brands", "Lattafa", "Afnan", "French Avenue", "Alhambra", "Paris Corner", "Armaf", "Maison Alhambra"];

export const PERFUMES = [
  {
    id: 1, name: "Oud For Glory", brand: "Lattafa", category: "unisex",
    price: 18500, originalPrice: 22000,
    notes: ["Oud", "Rose", "Musk", "Amber"],
    description: "A majestic oud fragrance that blends rich Agarwood with velvety rose and a warm amber base. Long-lasting and deeply luxurious.",
    size: "100ml EDP", rating: 4.9, reviews: 47, badge: "Best Seller",
    gradient: "linear-gradient(135deg, #2c1a00 0%, #6b3a1f 50%, #c9a84c 100%)",
    emoji: "🔮"
  },
  {
    id: 2, name: "Asad", brand: "Lattafa", category: "men",
    price: 16500, originalPrice: null,
    notes: ["Amber", "Tobacco", "Musk", "Vanilla"],
    description: "Bold and commanding, Asad opens with a smoky tobacco heart layered over warm amber and rich musk. A true statement scent.",
    size: "100ml EDP", rating: 4.8, reviews: 63, badge: "New",
    gradient: "linear-gradient(135deg, #1a0a00 0%, #4a1a00 50%, #8b4513 100%)",
    emoji: "🦁"
  },
  {
    id: 3, name: "Yara", brand: "Lattafa", category: "women",
    price: 14500, originalPrice: 17000,
    notes: ["Jasmine", "Rose", "Vanilla", "Musk"],
    description: "Yara is a delicate floral bouquet with a warm vanilla heart. Feminine, soft and irresistibly elegant.",
    size: "100ml EDP", rating: 4.7, reviews: 38, badge: "Best Seller",
    gradient: "linear-gradient(135deg, #2d0020 0%, #8b004a 50%, #ffb6c1 100%)",
    emoji: "🌸"
  },
  {
    id: 4, name: "Black Afgano", brand: "Afnan", category: "unisex",
    price: 21000, originalPrice: 25000,
    notes: ["Oud", "Patchouli", "Tobacco", "Musk"],
    description: "Dark, mysterious, and unforgettable. Black Afgano is a smoky, resinous oud masterpiece with deep patchouli and tobacco.",
    size: "100ml EDP", rating: 5.0, reviews: 29, badge: "Premium",
    gradient: "linear-gradient(135deg, #000000 0%, #1a1a2e 50%, #533483 100%)",
    emoji: "⚫"
  },
  {
    id: 5, name: "9PM", brand: "Afnan", category: "men",
    price: 19500, originalPrice: null,
    notes: ["Bergamot", "Amber", "Vanilla", "Musk"],
    description: "Inspired by a legendary night at 9PM. A fresh citrusy opening descends into a warm, sensual amber and vanilla drydown.",
    size: "100ml EDP", rating: 4.9, reviews: 82, badge: "Top Pick",
    gradient: "linear-gradient(135deg, #0a0a2e 0%, #1a1a6e 50%, #4444cc 100%)",
    emoji: "🌙"
  },
  {
    id: 6, name: "Supremacy Silver", brand: "Afnan", category: "men",
    price: 15000, originalPrice: 18000,
    notes: ["Bergamot", "Lavender", "Sandalwood", "Musk"],
    description: "A crisp, sophisticated fresh scent. Silver accords with lavender and sandalwood make this ideal for the modern gentleman.",
    size: "100ml EDP", rating: 4.6, reviews: 55, badge: null,
    gradient: "linear-gradient(135deg, #1a1a1a 0%, #4a4a4a 50%, #c0c0c0 100%)",
    emoji: "💎"
  },
  {
    id: 7, name: "Avenue Des Fleurs", brand: "French Avenue", category: "women",
    price: 13500, originalPrice: null,
    notes: ["Rose", "Jasmine", "Bergamot", "Sandalwood"],
    description: "A Parisian floral stroll. Crisp bergamot opens onto a lush rose and jasmine heart, softly wrapped in sandalwood.",
    size: "100ml EDP", rating: 4.5, reviews: 24, badge: null,
    gradient: "linear-gradient(135deg, #1a0020 0%, #6b0040 50%, #ff80bf 100%)",
    emoji: "🌹"
  },
  {
    id: 8, name: "Signature Gold", brand: "French Avenue", category: "unisex",
    price: 17500, originalPrice: 21000,
    notes: ["Amber", "Rose", "Oud", "Musk"],
    description: "An opulent signature blending golden amber with rich oud and soft rose. Wear it as your personal seal of luxury.",
    size: "100ml EDP", rating: 4.7, reviews: 31, badge: "Sale",
    gradient: "linear-gradient(135deg, #1a0a00 0%, #7a5200 50%, #ffd700 100%)",
    emoji: "✨"
  },
  {
    id: 9, name: "Andalucia", brand: "Alhambra", category: "women",
    price: 12500, originalPrice: null,
    notes: ["Jasmine", "Citrus", "Vanilla", "Musk"],
    description: "Sun-drenched and joyful, Andalucia evokes the warmth of southern Spain with radiant jasmine and fresh citrus.",
    size: "100ml EDP", rating: 4.4, reviews: 19, badge: null,
    gradient: "linear-gradient(135deg, #1a0f00 0%, #8b6914 50%, #ffa500 100%)",
    emoji: "☀️"
  },
  {
    id: 10, name: "Steadfast", brand: "Paris Corner", category: "men",
    price: 15500, originalPrice: 18500,
    notes: ["Tobacco", "Oud", "Amber", "Sandalwood"],
    description: "Steadfast is bold and unwavering — a powerful blend of tobacco leaf, oud resin and warm sandalwood. Commanding presence.",
    size: "100ml EDP", rating: 4.8, reviews: 41, badge: "Best Seller",
    gradient: "linear-gradient(135deg, #0a0500 0%, #3d1c00 50%, #7b3a00 100%)",
    emoji: "🏔️"
  },
  {
    id: 11, name: "Millionaire", brand: "Paris Corner", category: "men",
    price: 20000, originalPrice: 24000,
    notes: ["Bergamot", "Jasmine", "Amber", "Vanilla"],
    description: "Smell like a million dollars. Millionaire opens bright with bergamot, reveals a floral jasmine heart, and settles into pure luxury.",
    size: "100ml EDP", rating: 4.9, reviews: 58, badge: "Premium",
    gradient: "linear-gradient(135deg, #0a0a00 0%, #3d3d00 50%, #c8a800 100%)",
    emoji: "💰"
  },
  {
    id: 12, name: "Club De Nuit", brand: "Armaf", category: "men",
    price: 16000, originalPrice: null,
    notes: ["Bergamot", "Patchouli", "Amber", "Musk"],
    description: "The legendary Creed Aventus dupe that outperforms many originals. Fresh, smoky, iconic. A must-have.",
    size: "105ml EDP", rating: 5.0, reviews: 96, badge: "Iconic",
    gradient: "linear-gradient(135deg, #00001a 0%, #001a4d 50%, #0044cc 100%)",
    emoji: "🎩"
  },
  {
    id: 13, name: "Tres Nuit", brand: "Armaf", category: "men",
    price: 14000, originalPrice: 16500,
    notes: ["Lavender", "Bergamot", "Sandalwood", "Vanilla"],
    description: "A refined, versatile gentleman's fragrance. Lavender and bergamot open into a warm sandalwood and vanilla finish.",
    size: "100ml EDP", rating: 4.7, reviews: 44, badge: "Sale",
    gradient: "linear-gradient(135deg, #00001a 0%, #1a003d 50%, #6600cc 100%)",
    emoji: "🌌"
  },
  {
    id: 14, name: "Hayati", brand: "Maison Alhambra", category: "unisex",
    price: 13000, originalPrice: null,
    notes: ["Rose", "Oud", "Musk", "Amber"],
    description: "Hayati means 'my life' in Arabic. A deeply personal fragrance — rose and oud intertwined with musky warmth.",
    size: "100ml EDP", rating: 4.6, reviews: 27, badge: null,
    gradient: "linear-gradient(135deg, #1a0010 0%, #6b004a 50%, #c9006b 100%)",
    emoji: "❤️"
  },
  {
    id: 15, name: "Ameer Al Oud", brand: "Afnan", category: "unisex",
    price: 23000, originalPrice: 28000,
    notes: ["Oud", "Rose", "Sandalwood", "Amber"],
    description: "Prince of Oud — a royal composition of aged agarwood, Taif rose, and creamy sandalwood. Pure Middle Eastern luxury.",
    size: "100ml EDP", rating: 5.0, reviews: 35, badge: "Luxury",
    gradient: "linear-gradient(135deg, #0a0500 0%, #3d1c02 50%, #9b6910 100%)",
    emoji: "👑"
  },
  {
    id: 16, name: "Lady Millions", brand: "French Avenue", category: "women",
    price: 15000, originalPrice: null,
    notes: ["Raspberry", "Rose", "Jasmine", "Vanilla"],
    description: "Glamorous and confident — raspberry and rose fizz at the top while a rich jasmine-vanilla base leaves a trail of pure femininity.",
    size: "100ml EDP", rating: 4.8, reviews: 52, badge: "New",
    gradient: "linear-gradient(135deg, #2d0010 0%, #8b0050 50%, #ffaadd 100%)",
    emoji: "👸"
  },
];

export function getWhatsAppLink(perfumeName, size) {
  const msg = encodeURIComponent(`Hello W&S Fragrances! 👋\n\nI'd like to order:\n🌿 *${perfumeName}* (${size})\n\nPlease provide details on availability and delivery. Thank you!`);
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`;
}
