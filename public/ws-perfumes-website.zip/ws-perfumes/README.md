# W&S Fragrances — Website

## Deploy to Vercel

### Option 1: Vercel CLI
```bash
npm i -g vercel
vercel
```

### Option 2: GitHub + Vercel Dashboard
1. Push this folder to a GitHub repo
2. Go to vercel.com → New Project → Import your repo
3. Framework: Vite | Build: `npm run build` | Output: `dist`
4. Deploy!

## Local Development
```bash
npm install
npm run dev
```

## Features
- Full perfume catalogue (16 perfumes, 7 brands)
- Search + Filter by category, brand, fragrance notes
- WhatsApp order integration
- Customer reviews with submission form
- Contact form → WhatsApp
- Instagram & TikTok links
- Full SEO meta tags
- Mobile responsive
- Luxury dark gold theme

## WhatsApp Number
237672203290
